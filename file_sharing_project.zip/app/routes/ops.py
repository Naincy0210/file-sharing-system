from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from starlette.status import HTTP_400_BAD_REQUEST
from app.utils.auth import fake_login_required
import os

router = APIRouter()

UPLOAD_DIR = "uploaded_files"
ALLOWED_EXTENSIONS = {"pptx", "docx", "xlsx"}
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/login")
def ops_login():
    return {"message": "Ops user logged in (simulated)"}

@router.post("/upload")
def upload_file(file: UploadFile = File(...), user: str = Depends(fake_login_required)):
    ext = file.filename.split('.')[-1]
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=HTTP_400_BAD_REQUEST, detail="Invalid file type")
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as f:
        f.write(file.file.read())
    return {"message": f"Uploaded {file.filename}"}
