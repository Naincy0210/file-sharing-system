from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from app.utils.auth import create_encrypted_url, verify_encrypted_url
import os
import uuid

router = APIRouter()

FILES = ["report.docx", "slides.pptx", "data.xlsx"]  # Mocked file list
VERIFY_TOKENS = {}

@router.post("/signup")
def signup(email: str):
    token = str(uuid.uuid4())
    VERIFY_TOKENS[email] = token
    return {"encrypted_url": f"/client/verify-email/{token}"}

@router.get("/verify-email/{token}")
def verify_email(token: str):
    if token not in VERIFY_TOKENS.values():
        raise HTTPException(status_code=400, detail="Invalid token")
    return {"message": "Email verified"}

@router.post("/login")
def client_login():
    return {"message": "Client user logged in (simulated)"}

@router.get("/files")
def list_files():
    return {"files": FILES}

@router.get("/download-file/{file_id}")
def get_download_link(file_id: str):
    encrypted = create_encrypted_url(file_id)
    return {"download-link": f"/client/download/{encrypted}"}

@router.get("/download/{encrypted}")
def download(encrypted: str):
    file_id = verify_encrypted_url(encrypted)
    if file_id not in FILES:
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(f"uploaded_files/{file_id}", filename=file_id)
