import base64

SECRET = "my_secret_key"

def create_encrypted_url(file_id: str) -> str:
    combined = f"{file_id}:{SECRET}"
    encoded = base64.urlsafe_b64encode(combined.encode()).decode()
    return encoded

def verify_encrypted_url(encrypted: str) -> str:
    decoded = base64.urlsafe_b64decode(encrypted.encode()).decode()
    file_id, secret = decoded.split(":")
    if secret != SECRET:
        raise Exception("Unauthorized")
    return file_id

def fake_login_required():
    return "authenticated_user"
