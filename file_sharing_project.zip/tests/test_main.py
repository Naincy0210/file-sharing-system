from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_ops_login():
    response = client.post("/ops/login")
    assert response.status_code == 200

def test_client_signup():
    response = client.post("/client/signup?email=test@example.com")
    assert response.status_code == 200
